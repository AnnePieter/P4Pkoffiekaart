from smartcard.scard.scard import *
